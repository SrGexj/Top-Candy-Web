# Top Candy Web
¡Bienvenido al repositorio oficial de la web de Top Candy! Esta es la plataforma en línea de nuestra empresa, donde los usuarios pueden explorar nuestros productos, conocer nuestra historia y realizar compras.

Tabla de Contenidos
Descripción
Estructura del Proyecto
Instalación
Uso
Contribuir
Licencia
Descripción
Este repositorio contiene el código fuente de la web de Top Candy. Top Candy es una empresa dedicada a la fabricación, distribución y exportación de caramelos y chucherías, fundada en 2005 en Montijo, Badajoz. Hemos crecido para convertirnos en una marca global, llevando nuestros productos a numerosos países alrededor del mundo.# Top Candy Web
¡Bienvenido al repositorio oficial de la web de Top Candy! Esta es la plataforma en línea de nuestra empresa, donde los usuarios pueden explorar nuestros productos, conocer nuestra historia y realizar compras.

### Tabla de Contenidos
- Descripción

### Descripción
Este repositorio contiene el código fuente de la web de Top Candy. Top Candy es una empresa dedicada a la fabricación, distribución y exportación de caramelos y chucherías, fundada en 2005 en Montijo, Badajoz. Hemos crecido para convertirnos en una marca global, llevando nuestros productos a numerosos países alrededor del mundo.
